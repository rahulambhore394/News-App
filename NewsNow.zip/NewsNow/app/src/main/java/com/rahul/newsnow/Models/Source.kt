package com.rahul.newsnow.Models

data class Source(
    val id: String,
    val name: String
)